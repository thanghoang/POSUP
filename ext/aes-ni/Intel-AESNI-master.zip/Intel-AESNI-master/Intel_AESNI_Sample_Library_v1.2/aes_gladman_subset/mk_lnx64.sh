#!/bin/bash

./mk_lnx.sh 64
