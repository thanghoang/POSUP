#!/bin/bash

./mk_lnx.sh 86
