#!/bin/sh

./mk_lnx_bin.sh 64
