#!/bin/sh

./mk_lnx_lib.sh 86
